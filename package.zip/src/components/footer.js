import logo from '../components/Logo.png';
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
export default function Footer() {
 return(
   
      
      <footer>
     
     
     <div className="escolha">Sua melhor escolha!</div>
         
          
      
      
        
          
        
    </footer>
   
 ); 
}