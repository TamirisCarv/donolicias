export default function Section3(){
    return (

    
        <section className="section3">
          
   <div class="beneficios.cont">
   <div className="beneficios">Nossos benefícios</div>
   <div className="textobe">Na Donolícias, cada mordida é uma <b>experiência única </b>, onde a 
   massa fresca e macia derrete na boca, deixando um sabor inigualável. Com uma variedade
    irresistível de opções salgadas e doces, <b>nossos donuts são recheados com cuidado e 
    criatividade,</b> garantindo uma explosão de delícias em cada pedaço.</div>

   </div>
         
        

        
       
   </section>
    )
} 